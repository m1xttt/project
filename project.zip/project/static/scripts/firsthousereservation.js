jQuery.noConflict();
jQuery(document).ready(function($) {
    $("#term").mask("99/99");
});
jQuery(document).ready(function($) {
    $("#number").mask("9999999999999999");
});
jQuery(document).ready(function($) {
    $("#CVV").mask("999");
});